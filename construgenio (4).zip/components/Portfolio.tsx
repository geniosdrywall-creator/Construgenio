import React, { useState } from 'react';

interface Project {
  id: string;
  title: string;
  desc: string;
  imgs: string[];
  estimatedTime?: string;
}

const DEFAULT_PROJECTS: Project[] = [
  {
    id: 'p1',
    title: "Forro Drywall Premium",
    desc: "Execução de forro estruturado com acabamento de alto padrão e alinhamento perfeito.",
    imgs: ["https://res.cloudinary.com/dyspxryqh/image/upload/v1769383558/Screenshot_20260125_132427_Video_Player_fmbkwj.jpg"],
    estimatedTime: "5 DIAS"
  },
  {
    id: 'p2',
    title: "Estruturação Técnica",
    desc: "Montagem de perfis galvanizados com nivelamento a laser de alta precisão.",
    imgs: ["https://res.cloudinary.com/dyspxryqh/image/upload/v1769396201/Screenshot_20260125_232902_Gallery_je1aca.jpg"],
    estimatedTime: "3 DIAS"
  },
  {
    id: 'p3',
    title: "Iluminação LED Integrada",
    desc: "Instalação de perfis de LED embutidos em forros de gesso acartonado.",
    imgs: ["https://res.cloudinary.com/dyspxryqh/image/upload/v1769424553/Screenshot_20260125_131751_Video_Player_zeyir4.jpg"],
    estimatedTime: "2 DIAS"
  }
];

const Portfolio: React.FC = () => {
  const [viewingImg, setViewingImg] = useState<string | null>(null);

  return (
    <section className="space-y-8 md:space-y-12">
      <div className="border-b-2 border-black pb-4">
        <h2 className="text-2xl md:text-4xl font-black uppercase tracking-tighter italic leading-none mb-2">Trabalhos</h2>
        <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Portfólio ConstruGenio</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 md:gap-10">
        {DEFAULT_PROJECTS.map((project) => (
          <div key={project.id} className="group border border-black/10 bg-white p-3 md:p-4 rounded-xl shadow-sm hover:shadow-md transition-all cursor-pointer" onClick={() => setViewingImg(project.imgs[0])}>
            <div className="relative aspect-video sm:aspect-square overflow-hidden rounded-lg mb-4">
              <img 
                src={project.imgs[0]} 
                alt={project.title} 
                className="w-full h-full object-cover grayscale transition-all duration-500 group-hover:grayscale-0"
              />
              <div className="absolute top-3 left-3 bg-black text-white px-2 py-1 text-[8px] font-black uppercase tracking-widest rounded">
                {project.estimatedTime}
              </div>
            </div>
            <h3 className="text-xs font-black uppercase tracking-tight mb-2 border-b border-gray-100 pb-2">{project.title}</h3>
            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider leading-relaxed">{project.desc}</p>
          </div>
        ))}
      </div>

      {viewingImg && (
        <div className="fixed inset-0 z-[120] bg-black/95 flex items-center justify-center p-4 md:p-6 animate-in fade-in duration-300" onClick={() => setViewingImg(null)}>
           <div className="max-w-5xl w-full border-2 border-white rounded-lg overflow-hidden">
              <img src={viewingImg} className="w-full h-auto grayscale" alt="Full view" />
           </div>
           <p className="absolute bottom-8 text-white font-black text-[9px] uppercase tracking-[0.5em] text-center w-full">Toque para fechar</p>
        </div>
      )}
    </section>
  );
};

export default Portfolio;