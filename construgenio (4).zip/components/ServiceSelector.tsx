import React, { useState, useMemo } from 'react';
import { SERVICES } from '../constants';

interface Props {
  onAdd: (serviceId: string, quantity: number) => void;
}

const ServiceSelector: React.FC<Props> = ({ onAdd }) => {
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [selectedServiceId, setSelectedServiceId] = useState(SERVICES[0].id);
  const [quantity, setQuantity] = useState<string>('');

  const categories = useMemo(() => ['Todos', ...Array.from(new Set(SERVICES.map(s => s.category)))], []);
  
  const filteredServices = useMemo(() => 
    SERVICES.filter(s => selectedCategory === 'Todos' || s.category === selectedCategory)
  , [selectedCategory]);

  const currentService = useMemo(() => 
    SERVICES.find(s => s.id === selectedServiceId) || SERVICES[0]
  , [selectedServiceId]);

  const handleAdd = () => {
    const val = parseFloat(quantity);
    if (!isNaN(val) && val > 0) {
      onAdd(selectedServiceId, val);
      setQuantity('');
    }
  };

  return (
    <div className="space-y-8 bg-white border-2 border-black p-6 md:p-10 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
      <div className="space-y-6">
        <h2 className="text-2xl font-black uppercase tracking-tighter border-b-4 border-black inline-block">Seleção de Serviços</h2>
        
        <div className="flex flex-wrap gap-2">
          {categories.map(cat => (
            <button 
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 text-[10px] font-black uppercase tracking-widest border-2 transition-all ${selectedCategory === cat ? 'bg-black text-white border-black' : 'bg-white text-black border-black hover:bg-gray-100'}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <div className="space-y-2 max-h-[400px] overflow-y-auto pr-4 custom-scroll">
          {filteredServices.map(service => (
            <div 
              key={service.id}
              onClick={() => setSelectedServiceId(service.id)}
              className={`p-2 border-2 cursor-pointer transition-all flex items-center justify-between gap-3 group ${selectedServiceId === service.id ? 'bg-black text-white border-black' : 'bg-white border-black/10 hover:border-black'}`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-14 h-14 shrink-0 border-2 flex items-center justify-center overflow-hidden bg-gray-50 ${selectedServiceId === service.id ? 'border-white/20' : 'border-black'}`}>
                  {service.imageUrl ? (
                    <img 
                      src={service.imageUrl} 
                      className={`w-full h-full object-cover grayscale transition-all duration-300 group-hover:grayscale-0 ${selectedServiceId === service.id ? 'grayscale-0' : ''}`} 
                      alt={service.name} 
                    />
                  ) : (
                    <svg className={`w-6 h-6 ${selectedServiceId === service.id ? 'text-gray-500' : 'text-gray-300'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                    </svg>
                  )}
                </div>
                <div className="flex flex-col">
                  <span className="font-black text-[11px] uppercase leading-tight mb-1">{service.name}</span>
                  <span className={`text-[9px] font-bold uppercase ${selectedServiceId === service.id ? 'text-gray-400' : 'text-gray-400'}`}>R$ {service.price} / {service.unit}</span>
                </div>
              </div>
              {selectedServiceId === service.id && <span className="text-xs mr-2">●</span>}
            </div>
          ))}
        </div>

        <div className="bg-gray-100 p-6 md:p-8 border-2 border-black space-y-6 self-start">
          <div className="space-y-3">
            <label className="text-[11px] font-black uppercase tracking-widest block">Metragem / Quantidade ({currentService.unit})</label>
            <input 
              type="number"
              inputMode="decimal"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              placeholder="0.00"
              className="w-full bg-white border-4 border-black p-5 text-4xl font-black outline-none focus:bg-black focus:text-white transition-all"
            />
          </div>
          
          <button 
            onClick={handleAdd}
            disabled={!quantity}
            className="w-full py-5 bg-black text-white font-black uppercase tracking-[0.2em] text-xs border-2 border-black hover:bg-white hover:text-black transition-all disabled:opacity-30 active:scale-95"
          >
            Adicionar Projeto
          </button>
        </div>
      </div>
      <style>{`
        .custom-scroll::-webkit-scrollbar { width: 6px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #000; }
        .custom-scroll::-webkit-scrollbar-track { background: #eee; }
      `}</style>
    </div>
  );
};

export default ServiceSelector;