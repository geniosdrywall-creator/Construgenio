import React, { useMemo } from 'react';
import { BudgetItem, CalculatedMaterial } from '../types';
import { SERVICES } from '../constants';

interface Props {
  items: BudgetItem[];
}

const MaterialSummary: React.FC<Props> = ({ items }) => {
  const calculatedMaterials = useMemo(() => {
    const totals: Record<string, { quantity: number; unit: string }> = {};

    items.forEach(item => {
      const service = SERVICES.find(s => s.id === item.serviceId);
      if (service && service.materials) {
        service.materials.forEach(mat => {
          const key = mat.name;
          const totalForThisItem = mat.consumptionPerUnit * item.quantity;
          
          if (!totals[key]) {
            totals[key] = { quantity: 0, unit: mat.unit };
          }
          totals[key].quantity += totalForThisItem;
        });
      }
    });

    return Object.entries(totals).map(([name, data]) => ({
      name,
      totalQuantity: data.quantity,
      unit: data.unit
    })) as CalculatedMaterial[];
  }, [items]);

  if (items.length === 0 || calculatedMaterials.length === 0) return null;

  return (
    <div className="bg-white border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] animate-in fade-in duration-700">
      <div className="bg-black text-white p-6 md:p-8 flex items-center justify-between border-b-4 border-black">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-white text-black flex items-center justify-center shrink-0">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
            </svg>
          </div>
          <div>
            <h2 className="text-xl md:text-2xl font-black uppercase tracking-tighter italic leading-none">Insumos Estimados</h2>
            <p className="text-[9px] font-bold text-gray-500 uppercase tracking-[0.3em] mt-1">Quantitativos Técnicos</p>
          </div>
        </div>
        <span className="hidden md:block text-[10px] font-black border-2 border-white/20 px-3 py-1">REF: {new Date().getFullYear()}</span>
      </div>

      <div className="p-6 md:p-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-px bg-black border-2 border-black overflow-hidden">
          {calculatedMaterials.map((mat, idx) => (
            <div key={idx} className="flex items-center justify-between p-6 bg-white hover:bg-gray-50 transition-colors">
              <div className="flex flex-col pr-4">
                <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">Material</span>
                <span className="text-xs font-black text-black uppercase tracking-tight leading-tight">{mat.name}</span>
              </div>
              <div className="text-right flex flex-col items-end shrink-0">
                <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">Total</span>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-black text-black tabular-nums">
                    {mat.totalQuantity % 1 === 0 
                      ? mat.totalQuantity 
                      : mat.totalQuantity.toLocaleString('pt-BR', { maximumFractionDigits: 2 })}
                  </span>
                  <span className="text-[10px] font-black text-gray-400 uppercase">{mat.unit}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-10 p-6 border-4 border-black bg-gray-50 flex gap-4 items-center">
          <div className="w-8 h-8 bg-black text-white flex items-center justify-center font-black shrink-0">!</div>
          <p className="text-[11px] text-black font-bold leading-tight uppercase tracking-widest">
            Atenção: Recomendamos margem de <span className="underline decoration-2">10% para perdas</span>. Valores baseados em tabela técnica padrão.
          </p>
        </div>
      </div>
    </div>
  );
};

export default MaterialSummary;