import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-black text-white py-6 px-6 sticky top-0 z-50">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-white flex items-center justify-center p-1 shrink-0">
            <img 
              src="https://res.cloudinary.com/dyspxryqh/image/upload/v1769467875/Screenshot_20260126_135008_Gallery_icxylf.jpg" 
              className="w-full h-full object-contain grayscale" 
              alt="ConstruGenio"
            />
          </div>
          <div className="text-center md:text-left">
            <h1 className="text-3xl font-black uppercase tracking-tighter leading-none">
              CONSTRU<span className="text-gray-500">GENIO</span>
            </h1>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.3em]">Sistemas Construtivos</p>
          </div>
        </div>
        
        <div className="flex flex-col items-center md:items-end border-t md:border-t-0 md:border-l border-white/20 pt-4 md:pt-0 md:pl-6 w-full md:w-auto">
          <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest">Atendimento Comercial</span>
          <a href="tel:11913350870" className="text-xl font-black tabular-nums hover:text-gray-300 transition-colors">
            (11) 91335-0870
          </a>
        </div>
      </div>
    </header>
  );
};

export default Header;