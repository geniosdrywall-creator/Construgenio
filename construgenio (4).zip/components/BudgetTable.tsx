import React from 'react';
import { BudgetItem } from '../types';
import { SERVICES } from '../constants';

interface Props {
  items: BudgetItem[];
  onRemove: (id: string) => void;
  onUpdate: (id: string, updates: Partial<BudgetItem>) => void;
}

const BudgetTable: React.FC<Props> = ({ items, onRemove, onUpdate }) => {
  if (items.length === 0) return null;

  return (
    <div className="w-full space-y-4">
      <div className="flex items-center justify-between border-b-2 border-black pb-2">
        <h3 className="text-xl font-black uppercase tracking-tight italic">Itens do Orçamento</h3>
        <span className="text-[10px] font-bold text-gray-400 uppercase">{items.length} itens</span>
      </div>
      
      <div className="overflow-x-auto -mx-4 px-4 md:mx-0 md:px-0">
        <div className="min-w-[700px]">
          <table className="w-full text-left border-collapse border-2 border-black">
            <thead>
              <tr className="bg-black text-white">
                <th className="p-4 text-[10px] font-bold uppercase tracking-widest">Serviço / Descrição</th>
                <th className="p-4 text-[10px] font-bold uppercase tracking-widest text-center">Quantidade</th>
                <th className="p-4 text-[10px] font-bold uppercase tracking-widest text-right">Preço Un.</th>
                <th className="p-4 text-[10px] font-bold uppercase tracking-widest text-right">Subtotal</th>
                <th className="p-4 text-[10px] font-bold uppercase tracking-widest text-center print:hidden">Excluir</th>
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-black">
              {items.map(item => {
                const service = SERVICES.find(s => s.id === item.serviceId);
                if (!service) return null;

                return (
                  <tr key={item.id} className="bg-white hover:bg-gray-50 transition-colors group">
                    <td className="p-4">
                      <div className="flex flex-col">
                        <span className="font-black text-sm uppercase leading-tight">{service.name}</span>
                        <span className="text-[9px] text-gray-400 font-bold uppercase">{service.category}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center justify-center gap-2">
                        <input 
                          type="number"
                          value={item.quantity}
                          onChange={(e) => onUpdate(item.id, { quantity: Math.max(0, Number(e.target.value)) })}
                          className="w-20 border-2 border-black p-2 font-black text-center text-sm focus:bg-black focus:text-white transition-all outline-none"
                        />
                        <span className="text-[10px] font-black text-gray-400 uppercase">{service.unit}</span>
                      </div>
                    </td>
                    <td className="p-4 text-right text-sm font-bold tabular-nums">
                      R$ {service.price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="p-4 text-right font-black text-base tabular-nums">
                      R$ {(service.price * item.quantity).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="p-4 text-center print:hidden">
                      <button 
                        onClick={() => onRemove(item.id)}
                        className="p-2 hover:bg-red-500 hover:text-white transition-all rounded border border-transparent hover:border-black"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      <p className="text-[10px] text-gray-400 font-bold uppercase italic md:hidden">Deslize para o lado para ver todos os detalhes →</p>
    </div>
  );
};

export default BudgetTable;