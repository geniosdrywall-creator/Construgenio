
import { GoogleGenAI } from "@google/genai";
import { BudgetItem, ServiceItem } from "../types";
import { SERVICES } from "../constants";

export const getGenioAdvice = async (items: BudgetItem[]) => {
  if (items.length === 0) return "Adicione itens ao orçamento para receber conselhos profissionais.";

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const budgetDetails = items.map(item => {
    const service = SERVICES.find(s => s.id === item.serviceId);
    return `${service?.name}: ${item.quantity} ${service?.unit}`;
  }).join(", ");

  const prompt = `
    Como um especialista em construção civil (O ConstruGênio), analise este orçamento: ${budgetDetails}.
    Forneça 3 dicas curtas e valiosas para o cliente sobre esses serviços específicos. 
    Mantenha o tom profissional, direto e em português do Brasil.
    Formate como uma lista curta.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        temperature: 0.7,
        thinkingConfig: { thinkingBudget: 0 }
      }
    });

    return response.text || "Sem conselhos no momento.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "O Gênio está descansando. Tente novamente em instantes.";
  }
};
