import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import ServiceSelector from './components/ServiceSelector';
import BudgetTable from './components/BudgetTable';
import Portfolio from './components/Portfolio';
import MaterialSummary from './components/MaterialSummary';
import { BudgetItem } from './types';
import { SERVICES } from './constants';
import { getGenioAdvice } from './services/geminiService';

const WhatsAppFAB = () => (
  <a 
    href="https://wa.me/5511913350870?text=Olá, gostaria de um orçamento ConstruGenio."
    target="_blank" 
    rel="noopener noreferrer"
    className="fixed bottom-6 right-6 z-[100] print:hidden"
  >
    <div className="w-16 h-16 bg-black text-white flex items-center justify-center border-4 border-white shadow-2xl hover:scale-110 transition-all active:scale-95">
      <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
      </svg>
    </div>
  </a>
);

const App: React.FC = () => {
  const [items, setItems] = useState<BudgetItem[]>([]);
  const [clientInfo, setClientInfo] = useState({ name: '', address: '' });
  const [advice, setAdvice] = useState<string>('');
  const [loadingAdvice, setLoadingAdvice] = useState(false);

  const calculateTotal = useCallback(() => {
    return items.reduce((acc, item) => {
      const service = SERVICES.find(s => s.id === item.serviceId);
      return acc + (service ? service.price * item.quantity : 0);
    }, 0);
  }, [items]);

  const handleAddItem = (serviceId: string, quantity: number) => {
    setItems(prev => [...prev, {
      id: Math.random().toString(36).substr(2, 9),
      serviceId,
      quantity,
      description: ''
    }]);
  };

  const handleConsultGenio = async () => {
    setLoadingAdvice(true);
    try {
      const res = await getGenioAdvice(items);
      setAdvice(res);
    } catch (e) {
      setAdvice("ERRO TÉCNICO: Não foi possível processar a análise no momento.");
    } finally {
      setLoadingAdvice(false);
    }
  };

  const total = calculateTotal();

  return (
    <div className="min-h-screen bg-white text-black flex flex-col selection:bg-black selection:text-white">
      <Header />
      <WhatsAppFAB />

      <main className="max-w-6xl mx-auto px-4 md:px-6 py-12 space-y-16 md:space-y-24 w-full">
        
        {/* Identificação do Projeto */}
        <section className="border-[4px] border-black p-6 md:p-10 bg-white grid grid-cols-1 md:grid-cols-2 gap-8 relative">
          <div className="absolute top-0 right-0 bg-black text-white px-4 py-1 text-[9px] font-black uppercase tracking-widest">Controle de Projeto</div>
          <div className="space-y-1">
            <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Cliente / Solicitante</label>
            <input 
              type="text" 
              placeholder="NOME COMPLETO"
              className="w-full bg-transparent border-b-2 border-black py-2 text-xl font-black outline-none focus:border-gray-400 uppercase placeholder:text-gray-200"
              value={clientInfo.name}
              onChange={(e) => setClientInfo(prev => ({...prev, name: e.target.value}))}
            />
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Local da Execução</label>
            <input 
              type="text" 
              placeholder="ENDEREÇO DA OBRA"
              className="w-full bg-transparent border-b-2 border-black py-2 text-xl font-black outline-none focus:border-gray-400 uppercase placeholder:text-gray-200"
              value={clientInfo.address}
              onChange={(e) => setClientInfo(prev => ({...prev, address: e.target.value}))}
            />
          </div>
        </section>

        <ServiceSelector onAdd={handleAddItem} />

        {items.length > 0 && (
          <div className="space-y-20 animate-in fade-in slide-in-from-bottom-5 duration-500">
            
            <BudgetTable 
              items={items} 
              onRemove={(id) => setItems(prev => prev.filter(i => i.id !== id))}
              onUpdate={(id, up) => setItems(prev => prev.map(i => i.id === id ? {...i, ...up} : i))}
            />

            {/* Resumo Financeiro */}
            <div className="bg-black text-white p-10 md:p-16 flex flex-col md:flex-row items-center justify-between gap-10 shadow-[15px_15px_0px_0px_rgba(0,0,0,0.1)]">
              <div className="text-center md:text-left space-y-2">
                <p className="text-[10px] font-black uppercase tracking-[0.6em] text-gray-500">Valor Total do Orçamento</p>
                <h2 className="text-6xl md:text-8xl font-black tabular-nums tracking-tighter">
                  <span className="text-2xl align-top mr-2">R$</span>
                  {total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </h2>
              </div>
              <button 
                onClick={() => window.print()}
                className="w-full md:w-auto bg-white text-black px-12 py-6 font-black uppercase text-sm tracking-widest hover:bg-gray-200 transition-all active:scale-95 neo-shadow"
              >
                Gerar PDF / Imprimir
              </button>
            </div>

            <MaterialSummary items={items} />

            {/* ConsulGênio - Parecer IA */}
            <section className="bg-white border-[4px] border-black p-8 md:p-16 relative overflow-hidden">
               <div className="absolute -top-4 -left-4 w-20 h-20 bg-black rotate-45"></div>
              <div className="flex items-center gap-6 mb-10 relative z-10">
                <div className="w-16 h-16 bg-black text-white flex items-center justify-center text-4xl font-black shrink-0 italic shadow-[4px_4px_0px_0px_#ccc]">G</div>
                <div>
                    <h3 className="text-3xl font-black uppercase tracking-tighter leading-none italic">Consultoria Técnica IA</h3>
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">Análise de viabilidade e recomendações</p>
                </div>
              </div>
              
              {advice ? (
                <div className="bg-gray-50 p-8 md:p-12 font-bold leading-relaxed text-lg text-black border-l-[12px] border-black italic shadow-inner">
                  {advice.split('\n').map((line, i) => <p key={i} className="mb-2">{line}</p>)}
                </div>
              ) : (
                <button 
                  onClick={handleConsultGenio}
                  disabled={loadingAdvice}
                  className="w-full bg-black text-white py-8 font-black uppercase tracking-[0.4em] text-sm hover:bg-gray-900 transition-all disabled:opacity-50 active:scale-95"
                >
                  {loadingAdvice ? 'ANALISANDO PROJETO...' : 'SOLICITAR PARECER TÉCNICO DO GÊNIO'}
                </button>
              )}
            </section>
          </div>
        )}

        <Portfolio />
      </main>

      <footer className="bg-black text-white py-20 px-6 text-center border-t-[8px] border-gray-100">
        <div className="max-w-6xl mx-auto space-y-8">
           <h2 className="text-4xl font-black uppercase tracking-tighter italic">CONSTRU<span className="text-gray-500">GENIO</span></h2>
           <div className="w-32 h-2 bg-white mx-auto"></div>
           <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-[11px] font-bold uppercase tracking-widest text-gray-400">
              <p>QUALIDADE CERTIFICADA</p>
              <p>SISTEMAS CONSTRUTIVOS</p>
              <p>SÃO PAULO - BRASIL</p>
           </div>
           <p className="text-[9px] font-bold text-gray-600 uppercase tracking-[0.5em] pt-10">
             © 2026 ConstruGenio - Engenharia de Precisão
           </p>
        </div>
      </footer>
    </div>
  );
};

export default App;