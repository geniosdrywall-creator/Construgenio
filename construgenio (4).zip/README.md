# 🛠️ ConstruGenio - Sistemas Construtivos

Aplicativo de alta performance para orçamentos de construção civil.

## 🚀 Como colocar no ar (Netlify - Jeito Simples)

### 1. Preparar o Código
Certifique-se de que você tem uma conta no [GitHub](https://github.com) e este código está em um repositório lá.

### 2. Conectar ao Netlify
1. Vá para [Netlify.com](https://netlify.com) e faça login com sua conta do GitHub.
2. Clique em **"Add new site"** > **"Import an existing project"**.
3. Escolha **GitHub** e selecione o repositório `construgenio`.
4. O Netlify vai preencher as configurações sozinho (Build: `npm run build`, Publish: `dist`).

### 3. Configurar a Inteligência Artificial (Gemini)
Para o "ConsulGênio" funcionar, você precisa da chave da API:
1. No painel do seu site no Netlify, vá em **Site Configuration** > **Environment variables**.
2. Clique em **Add a variable**.
3. Em `Key` coloque: **`API_KEY`**
4. Em `Value` cole a sua chave que você pegou no [Google AI Studio](https://aistudio.google.com/).
5. Clique em **Save**.

### 4. Pronto!
O Netlify vai gerar um link (ex: `construgenio.netlify.app`) e seu site estará online.

---

## 🛠️ Tecnologias
- React 19 + Vite + Tailwind CSS
- Gemini AI API
- Architectural Black UI Design
