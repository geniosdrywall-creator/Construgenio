
export type UnitType = 'm²' | 'linear' | 'ponto' | 'unidade';

export interface MaterialRequirement {
  name: string;
  consumptionPerUnit: number;
  unit: string;
}

export interface ServiceItem {
  id: string;
  name: string;
  price: number;
  unit: UnitType;
  category: 'Drywall' | 'Pintura' | 'Elétrica' | 'Automação' | 'Iluminação';
  imageUrl?: string;
  materials?: MaterialRequirement[]; // Lista de materiais necessários por unidade (m², linear, etc)
}

export interface BudgetItem {
  id: string;
  serviceId: string;
  quantity: number;
  description: string;
}

export interface Budget {
  items: BudgetItem[];
  total: number;
}

export interface CalculatedMaterial {
  name: string;
  totalQuantity: number;
  unit: string;
}
