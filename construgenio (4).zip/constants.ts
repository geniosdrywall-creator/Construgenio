
import { ServiceItem } from './types';

export const SERVICES: ServiceItem[] = [
  // DRYWALL - FORROS
  { 
    id: 'f-dry-fga', 
    name: 'Forro Drywall Estruturado (FGA)', 
    price: 120, 
    unit: 'm²', 
    category: 'Drywall',
    imageUrl: 'https://res.cloudinary.com/dyspxryqh/image/upload/v1769473743/631a82_de8f9136d80c425c85a100c35e485da2_mv2_rjxmhc.png',
    materials: [
      { name: 'Placa Gesso Standard 12.5mm', consumptionPerUnit: 0.35, unit: 'un' },
      { name: 'Perfil F530 (3m)', consumptionPerUnit: 0.6, unit: 'un' },
      { name: 'Cantoneira Metálica (3m)', consumptionPerUnit: 0.2, unit: 'un' },
      { name: 'Massa para Drywall', consumptionPerUnit: 0.5, unit: 'kg' },
      { name: 'Fita de Papel Microperfurada', consumptionPerUnit: 1.5, unit: 'm' },
      { name: 'Parafuso GN25', consumptionPerUnit: 15, unit: 'un' }
    ]
  },
  { 
    id: 'f-dry-ru', 
    name: 'Forro Drywall RU (Resistente à Umidade)', 
    price: 140, 
    unit: 'm²', 
    category: 'Drywall',
    imageUrl: 'https://res.cloudinary.com/dyspxryqh/image/upload/v1769509063/Screenshot_20260127_065806_Google_vo0ysb.jpg',
    materials: [
      { name: 'Placa Gesso RU (Verde) 12.5mm', consumptionPerUnit: 0.35, unit: 'un' },
      { name: 'Perfil F530 (3m)', consumptionPerUnit: 0.6, unit: 'un' },
      { name: 'Cantoneira Metálica (3m)', consumptionPerUnit: 0.2, unit: 'un' },
      { name: 'Massa para Drywall', consumptionPerUnit: 0.5, unit: 'kg' },
      { name: 'Fita de Papel Microperfurada', consumptionPerUnit: 1.5, unit: 'm' }
    ]
  },
  
  // DRYWALL - PAREDES
  { 
    id: 'p-70mm', 
    name: 'Parede Drywall 70mm (Simples)', 
    price: 145, 
    unit: 'm²', 
    category: 'Drywall',
    imageUrl: 'https://res.cloudinary.com/dyspxryqh/image/upload/v1769511419/montante_drywall_48mm_3_metros_31577_2_05da50294fabae3a3cd290a81007e0fe_20211119132232_vq2w8s.jpg',
    materials: [
      { name: 'Placa Gesso Standard 12.5mm', consumptionPerUnit: 0.70, unit: 'un' },
      { name: 'Montante 70mm (3m)', consumptionPerUnit: 0.8, unit: 'un' },
      { name: 'Guia 70mm (3m)', consumptionPerUnit: 0.4, unit: 'un' },
      { name: 'Massa para Drywall', consumptionPerUnit: 0.9, unit: 'kg' },
      { name: 'Fita de Papel', consumptionPerUnit: 3.0, unit: 'm' },
      { name: 'Parafuso GN25', consumptionPerUnit: 30, unit: 'un' }
    ]
  },
  { 
    id: 'p-95mm', 
    name: 'Parede Drywall 95mm (Simples)', 
    price: 165, 
    unit: 'm²', 
    category: 'Drywall',
    imageUrl: 'https://res.cloudinary.com/dyspxryqh/image/upload/v1769519278/Screenshot_20260127_064955_Google_dbuamf.jpg',
    materials: [
      { name: 'Placa Gesso Standard 12.5mm', consumptionPerUnit: 0.70, unit: 'un' },
      { name: 'Montante 90mm (3m)', consumptionPerUnit: 0.8, unit: 'un' },
      { name: 'Guia 90mm (3m)', consumptionPerUnit: 0.4, unit: 'un' },
      { name: 'Massa para Drywall', consumptionPerUnit: 0.9, unit: 'kg' }
    ]
  },
  
  // PINTURA
  { 
    id: 'pt-mecanizada', 
    name: 'Pintura Airless (Mecanizada)', 
    price: 45, 
    unit: 'm²', 
    category: 'Pintura',
    imageUrl: 'https://res.cloudinary.com/dyspxryqh/image/upload/v1769550106/271362_maquina_de_pintura_airless_profissional_1600_psi_control_pro_130_etlmua.webp',
    materials: [
      { name: 'Tinta Acrílica Premium', consumptionPerUnit: 0.35, unit: 'L' },
      { name: 'Selador Acrílico', consumptionPerUnit: 0.15, unit: 'L' },
      { name: 'Lixa Massa 180', consumptionPerUnit: 0.1, unit: 'un' }
    ]
  },
  { 
    id: 'pt-manual', 
    name: 'Pintura Manual (Rolo/Pincel)', 
    price: 35, 
    unit: 'm²', 
    category: 'Pintura',
    imageUrl: 'https://images.unsplash.com/photo-1562259949-e8e7689d7828?auto=format&fit=crop&q=80&w=300',
    materials: [
      { name: 'Tinta Acrílica Standard', consumptionPerUnit: 0.3, unit: 'L' },
      { name: 'Lixa Massa 180', consumptionPerUnit: 0.15, unit: 'un' }
    ]
  },
  
  // ILUMINAÇÃO
  { 
    id: 'led-perfil', 
    name: 'Perfil LED de Embutir (Instalação)', 
    price: 110, 
    unit: 'linear', 
    category: 'Iluminação',
    imageUrl: 'https://res.cloudinary.com/dyspxryqh/image/upload/v1769531353/Screenshot_20260125_131751_Video_Player_yr7ldc.jpg',
    materials: [
      { name: 'Presilha para Perfil', consumptionPerUnit: 2, unit: 'un' },
      { name: 'Conector Wago', consumptionPerUnit: 1, unit: 'un' }
    ]
  },
  
  // ELÉTRICA
  { 
    id: 'el-ponto', 
    name: 'Ponto de Luz/Tomada', 
    price: 85, 
    unit: 'ponto', 
    category: 'Elétrica',
    imageUrl: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&q=80&w=300',
    materials: [
      { name: 'Fio Flexível 2.5mm (médio)', consumptionPerUnit: 5, unit: 'm' },
      { name: 'Caixa 4x2 PVC', consumptionPerUnit: 1, unit: 'un' }
    ]
  },
];
